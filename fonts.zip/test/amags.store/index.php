<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN" "http://www.w3.org/TR/html4/frameset.dtd">

<html>
  <head>
    <title>The Amags Store</title>
    <meta name="description" content="amags.tk">
    <meta name="keywords" content="amags.tk">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  </head>
  <frameset rows="*">
    <frame frameborder=0 src="https://pagecabinet.com/0/?fid=650498558301387" name="dot_tk_frame_content"  noresize>
  </frameset>
</html>
