<script>
window.location="../";
</script>